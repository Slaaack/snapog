import Link from "next/link";

export default function Home() {
  return (
    <div style={{ minHeight: "100vh" }}>
      {/* Nav */}
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "18px 28px",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <span
          style={{
            fontSize: "20px",
            fontWeight: 800,
            background: "linear-gradient(135deg, #f97316, #ec4899)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          SnapOG
        </span>
        <div style={{ display: "flex", gap: "12px" }}>
          <Link
            href="/checker"
            style={{
              padding: "8px 16px",
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "8px",
              color: "#aaa",
              fontSize: "12px",
              textDecoration: "none",
            }}
          >
            Free OG Checker
          </Link>
          <Link
            href="/app"
            style={{
              padding: "8px 16px",
              background: "linear-gradient(135deg, #f97316, #ec4899)",
              borderRadius: "8px",
              color: "#fff",
              fontSize: "12px",
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            Open App →
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <div
        style={{
          padding: "80px 28px 60px",
          textAlign: "center",
          maxWidth: "740px",
          margin: "0 auto",
        }}
      >
        <div
          style={{
            display: "inline-block",
            fontSize: "11px",
            letterSpacing: "2px",
            color: "#f97316",
            background: "rgba(249,115,22,0.1)",
            padding: "6px 16px",
            borderRadius: "20px",
            fontWeight: 700,
            marginBottom: "24px",
            textTransform: "uppercase",
          }}
        >
          Stop losing clicks to ugly link previews
        </div>
        <h1
          style={{
            fontSize: "clamp(36px, 6vw, 56px)",
            fontWeight: 800,
            margin: "0 0 20px",
            lineHeight: 1.1,
            color: "#fff",
          }}
        >
          Beautiful social images.
          <br />
          <span
            style={{
              background: "linear-gradient(135deg, #f97316, #ec4899)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Zero design skills.
          </span>
        </h1>
        <p
          style={{
            fontSize: "18px",
            color: "#777",
            lineHeight: 1.6,
            margin: "0 auto 36px",
            maxWidth: "520px",
          }}
        >
          Generate stunning Open Graph images for your blog posts, changelogs,
          and landing pages in under 10 seconds. Every shared link becomes a
          click magnet.
        </p>
        <div
          style={{
            display: "flex",
            gap: "12px",
            justifyContent: "center",
            flexWrap: "wrap",
          }}
        >
          <Link
            href="/app"
            style={{
              padding: "14px 36px",
              background: "linear-gradient(135deg, #f97316, #ec4899)",
              borderRadius: "10px",
              color: "#fff",
              fontSize: "16px",
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            Create Free Image →
          </Link>
          <Link
            href="/checker"
            style={{
              padding: "14px 28px",
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "10px",
              color: "#aaa",
              fontSize: "16px",
              textDecoration: "none",
            }}
          >
            Check Your URL
          </Link>
        </div>
      </div>

      {/* How it works */}
      <div
        style={{
          padding: "60px 28px",
          borderTop: "1px solid rgba(255,255,255,0.04)",
          maxWidth: "800px",
          margin: "0 auto",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "28px",
            fontWeight: 800,
            color: "#fff",
            margin: "0 0 48px",
          }}
        >
          Three steps. Ten seconds.
        </h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "24px",
          }}
        >
          {[
            {
              n: "1",
              t: "Type your title",
              d: "Enter your blog post title and subtitle. Pick a template and color theme.",
            },
            {
              n: "2",
              t: "Customize",
              d: "Adjust fonts, sizes, and colors. Live preview updates instantly.",
            },
            {
              n: "3",
              t: "Download or use API",
              d: "Get a 1200×630 PNG or use the API URL as your og:image — auto-generates for every post.",
            },
          ].map((step) => (
            <div
              key={step.n}
              style={{
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: "12px",
                padding: "28px",
              }}
            >
              <div
                style={{
                  width: "36px",
                  height: "36px",
                  borderRadius: "50%",
                  background:
                    "linear-gradient(135deg, rgba(249,115,22,0.2), rgba(236,72,153,0.2))",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "16px",
                  fontWeight: 800,
                  color: "#f97316",
                  marginBottom: "16px",
                }}
              >
                {step.n}
              </div>
              <h3
                style={{
                  margin: "0 0 8px",
                  fontSize: "16px",
                  color: "#eee",
                  fontWeight: 700,
                }}
              >
                {step.t}
              </h3>
              <p
                style={{
                  margin: 0,
                  fontSize: "13px",
                  color: "#777",
                  lineHeight: 1.6,
                }}
              >
                {step.d}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing */}
      <div
        style={{
          padding: "60px 28px",
          borderTop: "1px solid rgba(255,255,255,0.04)",
          maxWidth: "700px",
          margin: "0 auto",
          textAlign: "center",
        }}
      >
        <h2
          style={{
            fontSize: "28px",
            fontWeight: 800,
            color: "#fff",
            margin: "0 0 40px",
          }}
        >
          Simple pricing
        </h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "16px",
          }}
        >
          {[
            {
              tier: "Free",
              price: "$0",
              per: "forever",
              features: [
                "10 images/month",
                "Watermark",
                "3 templates",
                "PNG export",
              ],
              primary: false,
            },
            {
              tier: "Pro",
              price: "$9",
              per: "/month",
              features: [
                "Unlimited images",
                "No watermark",
                "All templates",
                "API access",
                "All themes",
              ],
              primary: true,
            },
            {
              tier: "Team",
              price: "$29",
              per: "/month",
              features: [
                "Everything in Pro",
                "5 team members",
                "Custom brand colors",
                "White-label API",
              ],
              primary: false,
            },
          ].map((plan) => (
            <div
              key={plan.tier}
              style={{
                background: plan.primary
                  ? "linear-gradient(135deg, rgba(249,115,22,0.08), rgba(236,72,153,0.08))"
                  : "rgba(255,255,255,0.02)",
                border: `1px solid ${plan.primary ? "rgba(249,115,22,0.25)" : "rgba(255,255,255,0.06)"}`,
                borderRadius: "14px",
                padding: "32px 24px",
                textAlign: "left",
              }}
            >
              <div
                style={{
                  fontSize: "13px",
                  color: plan.primary ? "#f97316" : "#888",
                  fontWeight: 700,
                  marginBottom: "8px",
                }}
              >
                {plan.tier}
              </div>
              <div style={{ marginBottom: "20px" }}>
                <span
                  style={{ fontSize: "36px", fontWeight: 800, color: "#fff" }}
                >
                  {plan.price}
                </span>
                <span style={{ fontSize: "13px", color: "#666" }}>
                  {plan.per}
                </span>
              </div>
              {plan.features.map((f) => (
                <div
                  key={f}
                  style={{
                    fontSize: "12px",
                    color: "#999",
                    padding: "4px 0",
                    display: "flex",
                    gap: "8px",
                  }}
                >
                  <span
                    style={{
                      color: plan.primary ? "#f97316" : "#555",
                      fontSize: "10px",
                    }}
                  >
                    ✓
                  </span>{" "}
                  {f}
                </div>
              ))}
              <Link
                href="/app"
                style={{
                  display: "block",
                  marginTop: "20px",
                  textAlign: "center",
                  padding: "10px",
                  background: plan.primary
                    ? "linear-gradient(135deg, #f97316, #ec4899)"
                    : "rgba(255,255,255,0.06)",
                  border: plan.primary
                    ? "none"
                    : "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                  color: plan.primary ? "#fff" : "#aaa",
                  fontSize: "13px",
                  fontWeight: 700,
                  textDecoration: "none",
                }}
              >
                Get Started
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer
        style={{
          padding: "40px 28px",
          borderTop: "1px solid rgba(255,255,255,0.04)",
          textAlign: "center",
          fontSize: "12px",
          color: "#444",
        }}
      >
        SnapOG · Beautiful social preview images in seconds
      </footer>
    </div>
  );
}
