import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SnapOG — Beautiful Social Preview Images in Seconds",
  description:
    "Generate stunning Open Graph images for your blog posts, changelogs, and landing pages. No design skills needed. Free to start.",
  openGraph: {
    title: "SnapOG — Beautiful Social Preview Images in Seconds",
    description: "Generate OG images in 10 seconds. No design skills needed.",
    url: "https://snapog.com",
    siteName: "SnapOG",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SnapOG — Beautiful Social Preview Images in Seconds",
    description: "Generate OG images in 10 seconds. No design skills needed.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body
        style={{
          margin: 0,
          padding: 0,
          background: "#06060B",
          color: "#d4d4d8",
          fontFamily: "'Trebuchet MS', 'Lucida Sans', sans-serif",
        }}
      >
        {children}
      </body>
    </html>
  );
}
